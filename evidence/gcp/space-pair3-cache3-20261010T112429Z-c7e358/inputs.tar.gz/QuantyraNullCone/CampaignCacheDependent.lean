import QuantyraNullCone.CampaignCacheProbe
namespace QuantyraNullCone
theorem campaign_cache_positive : 0 < campaignCacheValue := by norm_num [campaignCacheValue]
#print axioms campaign_cache_positive
end QuantyraNullCone
