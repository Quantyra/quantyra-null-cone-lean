import QuantyraNullCone.LorentzWeightedTime
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

namespace QuantyraNullCone

open MeasureTheory Set

noncomputable section

/-- Run two scalar velocities on the two half intervals, at twice their original speed. -/
def joinScalar3 (f g : ℝ → ℝ) (t : ℝ) : ℝ :=
  if t ≤ 1 / 2 then 2 * f (2 * t) else 2 * g (2 * t - 1)

theorem join_integrable_left3 {f g : ℝ → ℝ} (hf : IntervalIntegrable f volume 0 1) :
    IntervalIntegrable (joinScalar3 f g) volume 0 (1 / 2) := by
  have h : IntervalIntegrable (fun t => 2 * f (2 * t)) volume 0 (1 / 2) := by
    simpa using (hf.comp_mul_left (c := 2)).const_mul 2
  apply h.congr
  intro t ht
  have ht' : t ∈ Ioc (0 : ℝ) (1 / 2) := by simpa using ht
  simp [joinScalar3, ht'.2]

theorem join_integrable_right3 {f g : ℝ → ℝ} (hg : IntervalIntegrable g volume 0 1) :
    IntervalIntegrable (joinScalar3 f g) volume (1 / 2) 1 := by
  have h : IntervalIntegrable (fun t => 2 * g (2 * t - 1)) volume (1 / 2) 1 := by
    simpa using ((hg.comp_sub_right 1).comp_mul_left (c := 2)).const_mul 2
  apply h.congr
  intro t ht
  have ht' : t ∈ Ioc (1 / 2 : ℝ) 1 := by simpa using ht
  simp [joinScalar3, not_le.mpr ht'.1]

theorem join_integrable3 {f g : ℝ → ℝ} (hf : IntervalIntegrable f volume 0 1)
    (hg : IntervalIntegrable g volume 0 1) : IntervalIntegrable (joinScalar3 f g) volume 0 1 :=
  (join_integrable_left3 hf).trans (join_integrable_right3 hg)

theorem join_integral_left3 (f g : ℝ → ℝ) {t : ℝ} (ht : t ∈ Icc (0 : ℝ) (1 / 2)) :
    (∫ s in 0..t, joinScalar3 f g s) = ∫ s in 0..(2 * t), f s := by
  have heq : (∫ s in 0..t, joinScalar3 f g s) = ∫ s in 0..t, 2 * f (2 * s) := by
    apply intervalIntegral.integral_congr
    intro s hs
    have hs' : s ∈ Icc (0 : ℝ) t := by simpa [uIcc_of_le ht.1] using hs
    simp [joinScalar3, hs'.2.trans ht.2]
  rw [heq, intervalIntegral.integral_const_mul]
  simpa only [smul_eq_mul, mul_zero] using
    intervalIntegral.smul_integral_comp_mul_left f 2 (a := 0) (b := t)

theorem join_integral_right3 (f g : ℝ → ℝ) {t : ℝ} (ht : t ∈ Icc (1 / 2 : ℝ) 1) :
    (∫ s in (1 / 2)..t, joinScalar3 f g s) = ∫ s in 0..(2 * t - 1), g s := by
  have heq : (∫ s in (1 / 2)..t, joinScalar3 f g s) =
      ∫ s in (1 / 2)..t, 2 * g (2 * s - 1) := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards with s hs
    have hs' : s ∈ Ioc (1 / 2 : ℝ) t := by simpa [uIoc_of_le ht.1] using hs
    simp [joinScalar3, not_le.mpr hs'.1]
  rw [heq, intervalIntegral.integral_const_mul]
  have h := intervalIntegral.smul_integral_comp_mul_sub g 2 1 (a := (1 / 2)) (b := t)
  norm_num [smul_eq_mul] at h
  exact h

theorem join_integral3 {f g : ℝ → ℝ} (hf : IntervalIntegrable f volume 0 1)
    (hg : IntervalIntegrable g volume 0 1) :
    (∫ s in (0 : ℝ)..1, joinScalar3 f g s) = (∫ s in (0 : ℝ)..1, f s) + ∫ s in (0 : ℝ)..1, g s := by
  rw [← intervalIntegral.integral_add_adjacent_intervals
    (join_integrable_left3 hf) (join_integrable_right3 hg)]
  rw [join_integral_left3 f g (by constructor <;> norm_num),
    join_integral_right3 f g (by constructor <;> norm_num)]
  norm_num

theorem join_primitive_left3 {f g : ℝ → ℝ} (hf : AbsolutelyContinuousOnInterval f 0 1)
    {t : ℝ} (ht : t ∈ Icc (0 : ℝ) (1 / 2)) :
    f 0 + (∫ s in 0..t, joinScalar3 (deriv f) (deriv g) s) = f (2 * t) := by
  rw [join_integral_left3 _ _ ht]
  have hsub : uIcc (0 : ℝ) (2 * t) ⊆ uIcc (0 : ℝ) 1 := by
    rw [uIcc_of_le (by linarith : (0 : ℝ) ≤ 2 * t), uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)]
    exact Icc_subset_Icc le_rfl (by linarith [ht.2])
  rw [(hf.mono hsub).integral_deriv_eq_sub]
  ring

theorem join_primitive_right3 {f g : ℝ → ℝ} (hf : AbsolutelyContinuousOnInterval f 0 1)
    (hg : AbsolutelyContinuousOnInterval g 0 1) (hfg : f 1 = g 0)
    {t : ℝ} (ht : t ∈ Icc (1 / 2 : ℝ) 1) :
    f 0 + (∫ s in 0..t, joinScalar3 (deriv f) (deriv g) s) = g (2 * t - 1) := by
  have hsub : uIcc (1 / 2 : ℝ) t ⊆ uIcc (1 / 2 : ℝ) 1 := by
    rw [uIcc_of_le ht.1, uIcc_of_le (by norm_num : (1 / 2 : ℝ) ≤ 1)]
    exact Icc_subset_Icc le_rfl ht.2
  rw [← intervalIntegral.integral_add_adjacent_intervals
    (join_integrable_left3 hf.intervalIntegrable_deriv)
    ((join_integrable_right3 hg.intervalIntegrable_deriv).mono_set hsub)]
  rw [join_integral_left3 _ _ (by constructor <;> norm_num), join_integral_right3 _ _ ht]
  norm_num
  rw [hf.integral_deriv_eq_sub]
  have hsub' : uIcc (0 : ℝ) (2 * t - 1) ⊆ uIcc (0 : ℝ) 1 := by
    rw [uIcc_of_le (by linarith : (0 : ℝ) ≤ 2 * t - 1), uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)]
    exact Icc_subset_Icc le_rfl (by linarith [ht.2])
  rw [(hg.mono hsub').integral_deriv_eq_sub, hfg]
  ring

def joinedCoord3 {p q r : LorentzPoint3} (c : FutureCurve3 p q) (d : FutureCurve3 q r)
    (i : Fin 3) (t : ℝ) : ℝ :=
  p i + ∫ s in 0..t, joinScalar3 (deriv (c.coord i)) (deriv (d.coord i)) s

theorem joined_coord_AC3 {p q r : LorentzPoint3} (c : FutureCurve3 p q) (d : FutureCurve3 q r)
    (i : Fin 3) : AbsolutelyContinuousOnInterval (joinedCoord3 c d i) 0 1 := by
  have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => p i) 0 1 := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  exact hc.add ((join_integrable3 (c.coordAC i).intervalIntegrable_deriv
    (d.coordAC i).intervalIntegrable_deriv).absolutelyContinuousOnInterval_intervalIntegral (by simp))

theorem joined_coord_left3 {p q r : LorentzPoint3} (c : FutureCurve3 p q) (d : FutureCurve3 q r)
    (i : Fin 3) {t : ℝ} (ht : t ∈ Icc (0 : ℝ) (1 / 2)) :
    joinedCoord3 c d i t = c.coord i (2 * t) := by
  unfold joinedCoord3
  rw [← c.start i]
  exact join_primitive_left3 (c.coordAC i) ht

theorem joined_coord_right3 {p q r : LorentzPoint3} (c : FutureCurve3 p q) (d : FutureCurve3 q r)
    (i : Fin 3) {t : ℝ} (ht : t ∈ Icc (1 / 2 : ℝ) 1) :
    joinedCoord3 c d i t = d.coord i (2 * t - 1) := by
  unfold joinedCoord3
  rw [← c.start i]
  exact join_primitive_right3 (c.coordAC i) (d.coordAC i) (by rw [c.finish, d.start]) ht

theorem joined_coord_deriv3 {p q r : LorentzPoint3} (c : FutureCurve3 p q) (d : FutureCurve3 q r)
    (i : Fin 3) : ∀ᵐ t ∂curveMeasure, deriv (joinedCoord3 c d i) t =
      joinScalar3 (deriv (c.coord i)) (deriv (d.coord i)) t := by
  have h := (join_integrable3 (c.coordAC i).intervalIntegrable_deriv
    (d.coordAC i).intervalIntegrable_deriv).ae_hasDerivAt_integral
  have h' := ae_restrict_of_ae h (s := Icc (0 : ℝ) 1)
  filter_upwards [h', self_mem_ae_restrict measurableSet_Icc] with t ht hmem
  have hmem' : t ∈ uIcc (0 : ℝ) 1 := by simpa using hmem
  exact ((ht hmem' 0 (by simp)).const_add (p i)).deriv

#print axioms join_integrable_left3
#print axioms join_integrable_right3
#print axioms join_integrable3
#print axioms join_integral_left3
#print axioms join_integral_right3
#print axioms join_integral3
#print axioms join_primitive_left3
#print axioms join_primitive_right3
#print axioms joined_coord_AC3
#print axioms joined_coord_left3
#print axioms joined_coord_right3
#print axioms joined_coord_deriv3

end
end QuantyraNullCone
