import QuantyraNullCone.Bridges

namespace QuantyraNullCone

abbrev FiniteArc (n : ℕ) := Fin n × Fin n

def rowRelation {n : ℕ} (rows : Fin n → Fin n → Bool) (u v : Fin n) : Prop :=
  rows u v = true

instance {n : ℕ} (rows : Fin n → Fin n → Bool) (u v : Fin n) :
    Decidable (Incomparable (rowRelation rows) u v) :=
  inferInstanceAs (Decidable (u ≠ v ∧ ¬ rows u v = true ∧ ¬ rows v u = true))

instance {n : ℕ} (rows : Fin n → Fin n → Bool) (u v : Fin n) :
    Decidable (Comparable (rowRelation rows) u v) :=
  inferInstanceAs (Decidable (rows u v = true ∨ rows v u = true))

/-- This step always checks the original order table, never a deleted graph. -/
def originalForceStep {n : ℕ} (rows : Fin n → Fin n → Bool)
    (parent arc : FiniteArc n) : Bool :=
  decide ((parent.1 = arc.1 ∧ Incomparable (rowRelation rows) parent.1 parent.2 ∧
      Incomparable (rowRelation rows) arc.1 arc.2 ∧ Comparable (rowRelation rows) parent.2 arc.2) ∨
    (parent.2 = arc.2 ∧ Incomparable (rowRelation rows) parent.1 parent.2 ∧
      Incomparable (rowRelation rows) arc.1 arc.2 ∧ Comparable (rowRelation rows) parent.1 arc.1))

theorem Realizer.originalForceStep_sound {n : ℕ} {rows : Fin n → Fin n → Bool}
    (L : Realizer (rowRelation rows)) (parent arc : FiniteArc n)
    (h : originalForceStep rows parent arc = true) :
    L.opposite parent.1 parent.2 ↔ L.opposite arc.1 arc.2 := by
  rcases parent with ⟨a, b⟩
  rcases arc with ⟨u, v⟩
  have hStep := of_decide_eq_true h
  rcases hStep with ⟨rfl, hab, huv, hbv⟩ | ⟨rfl, hab, huv, hau⟩
  · exact L.forcing_at_left hab huv hbv
  · exact L.forcing_at_right hab huv hau

abbrev ForcingEntry (n : ℕ) := FiniteArc n × Option (FiniteArc n)

def forcingEntryValid {n : ℕ} (rows : Fin n → Fin n → Bool) (anchor : FiniteArc n)
    (seen : List (FiniteArc n)) (entry : ForcingEntry n) : Prop :=
  Incomparable (rowRelation rows) entry.1.1 entry.1.2 ∧ entry.1 ∉ seen ∧
    (entry.1.2, entry.1.1) ∉ seen ∧
    match entry.2 with
    | none => seen = [] ∧ entry.1 = anchor
    | some parent => parent ∈ seen ∧ originalForceStep rows parent entry.1 = true

instance {n : ℕ} (rows : Fin n → Fin n → Bool) (anchor : FiniteArc n)
    (seen : List (FiniteArc n)) (entry : ForcingEntry n) :
    Decidable (forcingEntryValid rows anchor seen entry) := by
  unfold forcingEntryValid
  split <;> infer_instance

/-- The computational witness-tree core of the finite-data verifier. -/
def checkForcingTraceFrom {n : ℕ} (rows : Fin n → Fin n → Bool) (anchor : FiniteArc n)
    (seen : List (FiniteArc n)) : List (ForcingEntry n) → Bool
  | [] => true
  | entry :: rest =>
    if forcingEntryValid rows anchor seen entry then
      checkForcingTraceFrom rows anchor (entry.1 :: seen) rest
    else false

def checkForcingTrace {n : ℕ} (rows : Fin n → Fin n → Bool) (anchor : FiniteArc n)
    (trace : List (ForcingEntry n)) : Bool := checkForcingTraceFrom rows anchor [] trace

theorem Realizer.checkForcingTraceFrom_sound {n : ℕ} {rows : Fin n → Fin n → Bool}
    (L : Realizer (rowRelation rows)) (anchor : FiniteArc n) (trace : List (ForcingEntry n)) :
    ∀ seen : List (FiniteArc n),
      (∀ arc ∈ seen, L.opposite arc.1 arc.2 ↔ L.opposite anchor.1 anchor.2) →
      checkForcingTraceFrom rows anchor seen trace = true →
      ∀ arc ∈ seen ++ trace.map Prod.fst,
        L.opposite arc.1 arc.2 ↔ L.opposite anchor.1 anchor.2 := by
  induction trace with
  | nil =>
    intro seen hSeen _ arc hArc
    exact hSeen arc (by simpa using hArc)
  | cons entry rest ih =>
    intro seen hSeen hAccept
    simp only [checkForcingTraceFrom] at hAccept
    split at hAccept
    next hValid =>
      have hLink : L.opposite entry.1.1 entry.1.2 ↔ L.opposite anchor.1 anchor.2 := by
        rcases hValid with ⟨_, _, _, hParent⟩
        cases hEntry : entry.2 with
        | none =>
          simp only [hEntry] at hParent
          rw [hParent.2]
        | some parent =>
          simp only [hEntry] at hParent
          exact (L.originalForceStep_sound parent entry.1 hParent.2).symm.trans
            (hSeen parent hParent.1)
      have hNew : ∀ arc ∈ entry.1 :: seen,
          L.opposite arc.1 arc.2 ↔ L.opposite anchor.1 anchor.2 := by
        intro arc hArc
        rcases List.mem_cons.mp hArc with rfl | hArc
        · exact hLink
        · exact hSeen arc hArc
      have hRest := ih (entry.1 :: seen) hNew hAccept
      intro arc hArc
      apply hRest arc
      simpa only [List.map_cons, List.mem_append, List.mem_cons, or_assoc, or_comm,
        or_left_comm] using hArc
    next => simp_all

theorem Realizer.checkForcingTrace_sound {n : ℕ} {rows : Fin n → Fin n → Bool}
    (L : Realizer (rowRelation rows)) (anchor : FiniteArc n) (trace : List (ForcingEntry n))
    (hAccept : checkForcingTrace rows anchor trace = true) :
    ∀ arc ∈ trace.map Prod.fst, L.opposite arc.1 arc.2 ↔ L.opposite anchor.1 anchor.2 := by
  have h := L.checkForcingTraceFrom_sound anchor trace [] (by simp) hAccept
  simpa using h

#print axioms Realizer.originalForceStep_sound
#print axioms Realizer.checkForcingTrace_sound

end QuantyraNullCone
