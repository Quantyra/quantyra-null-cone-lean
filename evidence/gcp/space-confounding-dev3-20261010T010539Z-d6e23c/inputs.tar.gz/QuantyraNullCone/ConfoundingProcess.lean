import QuantyraNullCone.ConfoundingMarked

namespace QuantyraNullCone

open MeasureTheory

theorem calibration_finite_count_equal {epsilon : ℝ} (he : 0 ≤ epsilon)
    (heSmall : epsilon ≤ 1/2) (N n : ℕ) :
    (Measure.pi (fun _ : Fin N => (densityMeasure lowerFlat).prod uniform01Measure))
      (retainedCountEvent (fun _ => 1-epsilon) N n) =
    (Measure.pi (fun _ : Fin N => (densityMeasure (calibrationDensity epsilon)).prod uniform01Measure))
      (retainedCountEvent (calibrationDetector epsilon) N n) := by
  letI := lower_flat_in_class.isProbabilityMeasure
  letI := (calibration_density_in_class he heSmall).isProbabilityMeasure
  rw [finite_retained_count_mass _ measurable_const (integrable_const _)
      (fun _ => ⟨by linarith, by linarith⟩),
    finite_retained_count_mass _ (calibration_detector_continuous heSmall).measurable
      (calibration_detector_integrable he heSmall) (calibration_detector_unit he heSmall),
    calibration_acceptance_mass he heSmall]
  simp

theorem calibration_finite_submeasure_equal {epsilon : ℝ} (he : 0 ≤ epsilon)
    (heSmall : epsilon ≤ 1/2) (N n : ℕ) (fallback : DiamondPoint) :
    ((Measure.pi (fun _ : Fin N => (densityMeasure lowerFlat).prod uniform01Measure)).restrict
      (retainedCountEvent (fun _ => 1-epsilon) N n)).map
        (retainedOrderedView (fun _ => 1-epsilon) fallback n) =
    ((Measure.pi (fun _ : Fin N => (densityMeasure (calibrationDensity epsilon)).prod uniform01Measure)).restrict
      (retainedCountEvent (calibrationDetector epsilon) N n)).map
        (retainedOrderedView (calibrationDetector epsilon) fallback n) := by
  letI := lower_flat_in_class.isProbabilityMeasure
  letI := (calibration_density_in_class he heSmall).isProbabilityMeasure
  have hc : 0 < 1-epsilon := by linarith
  have hZ : 0 < ∫ _ : DiamondPoint, 1-epsilon ∂densityMeasure lowerFlat := by simpa using hc
  rw [retained_count_submeasure_law _ measurable_const (integrable_const _)
      (fun _ => ⟨hc.le, by linarith⟩) hZ,
    retained_count_submeasure_law _ (calibration_detector_continuous heSmall).measurable
      (calibration_detector_integrable he heSmall) (calibration_detector_unit he heSmall)
      (by rw [calibration_acceptance_mass he heSmall]; exact hc),
    calibration_finite_count_equal he heSmall, calibration_flat_retained heSmall,
    calibration_retained_flat he heSmall]

theorem calibration_mixed_count_equal {epsilon : ℝ} (he : 0 ≤ epsilon)
    (heSmall : epsilon ≤ 1/2) (q : Measure ℕ) (n : ℕ) :
    (randomGeneratedLaw (densityMeasure lowerFlat) q)
      {z | mixedRetainedCount (fun _ => 1-epsilon) z = n} =
    (randomGeneratedLaw (densityMeasure (calibrationDensity epsilon)) q)
      {z | mixedRetainedCount (calibrationDetector epsilon) z = n} := by
  letI := lower_flat_in_class.isProbabilityMeasure
  letI := (calibration_density_in_class he heSmall).isProbabilityMeasure
  have hc : 0 < 1-epsilon := by linarith
  have hZ : 0 < ∫ _ : DiamondPoint, 1-epsilon ∂densityMeasure lowerFlat := by simpa using hc
  rw [mixed_retained_count_mass _ q measurable_const (integrable_const _)
      (fun _ => ⟨hc.le, by linarith⟩) hZ n (0,0),
    mixed_retained_count_mass _ q (calibration_detector_continuous heSmall).measurable
      (calibration_detector_integrable he heSmall) (calibration_detector_unit he heSmall)
      (by rw [calibration_acceptance_mass he heSmall]; exact hc) n (0,0)]
  simp_rw [calibration_finite_count_equal he heSmall]

/-- Any common independently chosen generated count, including fixed and Poisson counts. -/
theorem calibration_mixed_observable_equal {epsilon : ℝ} (he : 0 ≤ epsilon)
    (heSmall : epsilon ≤ 1/2) (q : Measure ℕ) [IsProbabilityMeasure q]
    (fallback : DiamondPoint) {Y : Type*} [MeasurableSpace Y]
    (F : (n : ℕ) → (Fin n → DiamondPoint) → Y) (hF : ∀ n, Measurable (F n)) :
    (randomGeneratedLaw (densityMeasure lowerFlat) q).map
      (mixedRetainedObservable (fun _ => 1-epsilon) fallback F) =
    (randomGeneratedLaw (densityMeasure (calibrationDensity epsilon)) q).map
      (mixedRetainedObservable (calibrationDetector epsilon) fallback F) := by
  letI := lower_flat_in_class.isProbabilityMeasure
  letI := (calibration_density_in_class he heSmall).isProbabilityMeasure
  have hc : 0 < 1-epsilon := by linarith
  have hZ : 0 < ∫ _ : DiamondPoint, 1-epsilon ∂densityMeasure lowerFlat := by simpa using hc
  rw [mixed_retained_observable_law _ q measurable_const (integrable_const _)
      (fun _ => ⟨hc.le, by linarith⟩) hZ fallback F hF,
    mixed_retained_observable_law _ q (calibration_detector_continuous heSmall).measurable
      (calibration_detector_integrable he heSmall) (calibration_detector_unit he heSmall)
      (by rw [calibration_acceptance_mass he heSmall]; exact hc) fallback F hF]
  simp_rw [calibration_mixed_count_equal he heSmall,
    calibration_flat_retained heSmall, calibration_retained_flat he heSmall]

abbrev CountedMarkedOrderCode (m : ℕ) := (n : ℕ) × UnlabeledMarkedOrderCode n m

noncomputable def countedMarkedOrder {m : ℕ} (anchors : Fin m → DiamondPoint)
    (n : ℕ) (sample : Fin n → DiamondPoint) : CountedMarkedOrderCode m :=
  ⟨n, sampledUnlabeledMarkedOrder anchors sample⟩

theorem counted_marked_order_measurable {m : ℕ} (anchors : Fin m → DiamondPoint) (n : ℕ) :
    Measurable (countedMarkedOrder anchors n) :=
  (measurable_of_countable (fun code : UnlabeledMarkedOrderCode n m =>
    (⟨n, code⟩ : CountedMarkedOrderCode m))).comp (sampled_unlabeled_marked_order_measurable anchors)

theorem calibration_mixed_marked_equal {epsilon : ℝ} (he : 0 ≤ epsilon)
    (heSmall : epsilon ≤ 1/2) (q : Measure ℕ) [IsProbabilityMeasure q]
    (fallback : DiamondPoint) {m : ℕ} (anchors : Fin m → DiamondPoint) :
    (randomGeneratedLaw (densityMeasure lowerFlat) q).map
      (mixedRetainedObservable (fun _ => 1-epsilon) fallback (countedMarkedOrder anchors)) =
    (randomGeneratedLaw (densityMeasure (calibrationDensity epsilon)) q).map
      (mixedRetainedObservable (calibrationDetector epsilon) fallback (countedMarkedOrder anchors)) :=
  calibration_mixed_observable_equal he heSmall q fallback _ (counted_marked_order_measurable anchors)

end QuantyraNullCone
