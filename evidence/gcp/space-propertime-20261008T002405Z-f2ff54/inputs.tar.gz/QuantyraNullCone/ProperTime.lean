import QuantyraNullCone.ImprovedInverse
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Function.L2Space

namespace QuantyraNullCone

open MeasureTheory Set

noncomputable def curveMeasure : Measure ℝ := volume.restrict (Icc (0 : ℝ) 1)

/-- Actual absolutely continuous future curves in the closed null-coordinate diamond. -/
structure FutureCurve (p q : DiamondPoint) where
  u : ℝ → ℝ
  v : ℝ → ℝ
  uAC : AbsolutelyContinuousOnInterval u 0 1
  vAC : AbsolutelyContinuousOnInterval v 0 1
  startU : u 0 = p.1
  startV : v 0 = p.2
  endU : u 1 = q.1
  endV : v 1 = q.2
  inDiamond : ∀ t ∈ Icc (0 : ℝ) 1, (u t, v t) ∈ diamond
  futureU : ∀ᵐ t ∂curveMeasure, 0 ≤ deriv u t
  futureV : ∀ᵐ t ∂curveMeasure, 0 ≤ deriv v t

def FutureCurve.point {p q : DiamondPoint} (c : FutureCurve p q) (t : ℝ) :
    DiamondPoint := (c.u t, c.v t)

noncomputable def FutureCurve.weight {p q : DiamondPoint} (c : FutureCurve p q)
    (t : ℝ) : ℝ := Real.sqrt (deriv c.u t * deriv c.v t)

/-- The Lorentzian length integrand from the paper, with no assumed length estimate. -/
noncomputable def FutureCurve.length {p q : DiamondPoint} (c : FutureCurve p q)
    (rho : DiamondPoint → ℝ) : ℝ :=
  ∫ t, Real.sqrt (2 * rho (c.point t) * deriv c.u t * deriv c.v t) ∂curveMeasure

theorem FutureCurve.integrable_derivU {p q : DiamondPoint} (c : FutureCurve p q) :
    Integrable (deriv c.u) curveMeasure := by
  exact (intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
    c.uAC.intervalIntegrable_deriv

theorem FutureCurve.integrable_derivV {p q : DiamondPoint} (c : FutureCurve p q) :
    Integrable (deriv c.v) curveMeasure := by
  exact (intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
    c.vAC.intervalIntegrable_deriv

theorem FutureCurve.integral_derivU {p q : DiamondPoint} (c : FutureCurve p q) :
    (∫ t, deriv c.u t ∂curveMeasure) = q.1 - p.1 := by
  change (∫ t in Icc (0 : ℝ) 1, deriv c.u t) = _
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le (by norm_num)]
  rw [c.uAC.integral_deriv_eq_sub, c.endU, c.startU]

theorem FutureCurve.integral_derivV {p q : DiamondPoint} (c : FutureCurve p q) :
    (∫ t, deriv c.v t ∂curveMeasure) = q.2 - p.2 := by
  change (∫ t in Icc (0 : ℝ) 1, deriv c.v t) = _
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le (by norm_num)]
  rw [c.vAC.integral_deriv_eq_sub, c.endV, c.startV]

theorem sqrt_coefficient_lipschitz {a b : ℝ} (ha : 1 / 2 ≤ a) (hb : 1 / 2 ≤ b) :
    |Real.sqrt (2 * a) - Real.sqrt (2 * b)| ≤ |a - b| := by
  have ha0 : 0 ≤ 2 * a := by linarith
  have hb0 : 0 ≤ 2 * b := by linarith
  have ha1 : 1 ≤ Real.sqrt (2 * a) := by
    apply Real.le_sqrt_of_sq_le
    nlinarith
  have hb1 : 1 ≤ Real.sqrt (2 * b) := by
    apply Real.le_sqrt_of_sq_le
    nlinarith
  have hsqA := Real.sq_sqrt ha0
  have hsqB := Real.sq_sqrt hb0
  have hId : (Real.sqrt (2 * a) - Real.sqrt (2 * b)) *
      (Real.sqrt (2 * a) + Real.sqrt (2 * b)) = 2 * (a - b) := by nlinarith
  have hAbs := congrArg abs hId
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ Real.sqrt (2 * a) + Real.sqrt (2 * b)),
    abs_mul, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2)] at hAbs
  have hNonneg := abs_nonneg (Real.sqrt (2 * a) - Real.sqrt (2 * b))
  nlinarith

theorem sqrt_memLp_two {f : ℝ → ℝ} {μ : Measure ℝ}
    (hf : Integrable f μ) (hPos : ∀ᵐ t ∂μ, 0 ≤ f t) :
    MemLp (fun t => Real.sqrt (f t)) 2 μ := by
  apply (memLp_two_iff_integrable_sq
    (Real.continuous_sqrt.comp_aestronglyMeasurable hf.aestronglyMeasurable)).mpr
  apply hf.congr
  filter_upwards [hPos] with t ht
  exact (Real.sq_sqrt ht).symm

theorem FutureCurve.weight_eq {p q : DiamondPoint} (c : FutureCurve p q) :
    c.weight =ᵐ[curveMeasure] fun t => Real.sqrt (deriv c.u t) *
      Real.sqrt (deriv c.v t) := by
  filter_upwards [c.futureU] with t ht
  exact Real.sqrt_mul ht _

theorem FutureCurve.integrable_weight {p q : DiamondPoint} (c : FutureCurve p q) :
    Integrable c.weight curveMeasure := by
  have hu := sqrt_memLp_two c.integrable_derivU c.futureU
  have hv := sqrt_memLp_two c.integrable_derivV c.futureV
  exact (hu.integrable_mul hv).congr c.weight_eq.symm

theorem FutureCurve.integral_weight_cauchy_schwarz {p q : DiamondPoint}
    (c : FutureCurve p q) :
    (∫ t, c.weight t ∂curveMeasure) ≤ Real.sqrt (q.1 - p.1) * Real.sqrt (q.2 - p.2) := by
  have hu := sqrt_memLp_two c.integrable_derivU c.futureU
  have hv := sqrt_memLp_two c.integrable_derivV c.futureV
  have hHolder : (2 : ℝ).HolderConjugate 2 := by
    rw [Real.holderConjugate_iff]
    norm_num
  have h := integral_mul_le_Lp_mul_Lq_of_nonneg hHolder
    (Filter.Eventually.of_forall (fun t => Real.sqrt_nonneg (deriv c.u t)))
    (Filter.Eventually.of_forall (fun t => Real.sqrt_nonneg (deriv c.v t)))
    (by simpa using hu) (by simpa using hv)
  have hU : (∫ t, (Real.sqrt (deriv c.u t)) ^ (2 : ℝ) ∂curveMeasure) = q.1 - p.1 := by
    rw [← c.integral_derivU]
    apply integral_congr_ae
    filter_upwards [c.futureU] with t ht
    rw [Real.rpow_two, Real.sq_sqrt ht]
  have hV : (∫ t, (Real.sqrt (deriv c.v t)) ^ (2 : ℝ) ∂curveMeasure) = q.2 - p.2 := by
    rw [← c.integral_derivV]
    apply integral_congr_ae
    filter_upwards [c.futureV] with t ht
    rw [Real.rpow_two, Real.sq_sqrt ht]
  rw [hU, hV, ← Real.sqrt_eq_rpow, ← Real.sqrt_eq_rpow] at h
  exact (integral_congr_ae c.weight_eq).le.trans h

theorem FutureCurve.integral_weight_le_one {p q : DiamondPoint} (c : FutureCurve p q) :
    (∫ t, c.weight t ∂curveMeasure) ≤ 1 := by
  have hp := c.inDiamond 0 (by constructor <;> norm_num)
  have hq := c.inDiamond 1 (by constructor <;> norm_num)
  rw [c.startU, c.startV] at hp
  rw [c.endU, c.endV] at hq
  have hu : Real.sqrt (q.1 - p.1) ≤ 1 := by
    apply (Real.sqrt_le_left (by norm_num)).mpr
    rcases hp with ⟨hpU, _⟩
    rcases hq with ⟨hqU, _⟩
    nlinarith [hpU.1, hqU.2]
  have hv : Real.sqrt (q.2 - p.2) ≤ 1 := by
    apply (Real.sqrt_le_left (by norm_num)).mpr
    rcases hp with ⟨_, hpV⟩
    rcases hq with ⟨_, hqV⟩
    nlinarith [hpV.1, hqV.2]
  have h := c.integral_weight_cauchy_schwarz
  have hprod := mul_le_mul hu hv (Real.sqrt_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
  norm_num at hprod
  exact h.trans hprod

#print axioms FutureCurve.integral_derivU
#print axioms sqrt_coefficient_lipschitz

end QuantyraNullCone
