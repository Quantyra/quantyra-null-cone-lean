import QuantyraNullCone.CDFReportCalibration

namespace QuantyraNullCone

def cdfFixtureChain : OrderCode 3 := fun i j => decide (i < j)

def cdfFixtureReport : CDFReport 3 where
  first := id
  second := id
  anchor := (0, 0)
  trace := []
  cutoff := 0
  radius := 1 / 50

example : checkCDFReport cdfFixtureChain cdfFixtureReport 100 0 0 = true := by decide
example : checkCDFReport cdfFixtureChain {cdfFixtureReport with radius := 0} 100 0 0 = false := by decide
example : reportCornerCount cdfFixtureReport 3 1 1 = 1 := by decide
example : reportCornerCount cdfFixtureReport 3 0 3 = 0 := by decide
example : reportCornerCount cdfFixtureReport 3 3 3 = 3 := by decide
example : permutationPositions (by decide : 0 < 3) ![2, 0, 1] 2 = 0 := by decide
example : checkSplitCalibrationOrFallback 1 1 0 0 (1 / 40) (1 / 40) (1 / 20) = true := by decide
example : reportRadiusQ cdfFixtureChain cdfFixtureReport 1 0 0 = 1 := by decide

end QuantyraNullCone
