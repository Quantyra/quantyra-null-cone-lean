import QuantyraNullCone.LorentzDensityForward
namespace QuantyraNullCone
def campaignCacheValue : Nat := 1
theorem campaign_cache_value : campaignCacheValue = 1 := rfl
#print axioms campaign_cache_value
end QuantyraNullCone
