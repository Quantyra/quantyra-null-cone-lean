import QuantyraNullCone.DensityReportCoverage
import QuantyraNullCone.CDFReportFixtures

namespace QuantyraNullCone

def densityFixtureCDF : CDFReport 3 := {cdfFixtureReport with radius := 1 / 10}

def densityFixtureA : List (List ℚ) :=
  [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0],
   [0,0,0,0], [0,0,0,0], [1,0,0,0], [-1,0,0,0], [1,1,0,0], [-1,-1,0,0],
   [0,0,0,0], [0,0,0,0], [1,0,1,0], [-1,0,-1,0], [1,1,1,1], [-1,-1,-1,-1],
   [1,0,-1,0], [-1,0,1,0], [1,-1,0,0], [-1,1,0,0],
   [0,1,0,-1], [0,-1,0,1], [0,0,1,-1], [0,0,-1,1]]

def densityFixtureE : List (List ℚ) := [[1,1,0,0], [0,0,1,1], [1,0,1,0], [0,1,0,1]]

def densityFixtureB : List ℚ :=
  [2/5,2/5,2/5,2/5,2/5,2/5,2/5,2/5,26/15,-14/15,26/15,-14/15,
   2/5,2/5,26/15,-14/15,22/5,-18/5,1,1,1,1,1,1,1,1]

theorem density_fixture_matrix :
    List.ofFn (fun i => List.ofFn (densityLP_A 2 i)) = densityFixtureA := by decide

theorem density_fixture_equalities :
    List.ofFn (fun i => List.ofFn (densityLP_E 2 i)) = densityFixtureE := by decide

theorem density_fixture_right : List.ofFn (densityLP_b densityFixtureCDF 2) = densityFixtureB := by decide

theorem density_fixture_dimensions :
    (densityInequalityRows 2).length = 26 ∧ (densityEqualityRows 2).length = 4 := by decide

def densityFixtureY : Fin (densityInequalityRows 2).length → ℚ := fun i => if i.val = 8 then -1 else 0
def densityFixtureZ : Fin (densityEqualityRows 2).length → ℚ :=
  fun i => if i.val = 0 then 1/3 else if i.val = 3 then -1/5 else 0

theorem density_fixture_residual :
    List.ofFn (rationalResidual (densityLP_A 2) (densityLP_E 2)
      (densityCellObjective (0 : Fin (2 * 2))) densityFixtureY densityFixtureZ) = [5/3,-2/15,0,1/5] := by decide

theorem density_fixture_dual_bound :
    densityLPDualLower densityFixtureCDF 2 (densityCellObjective (0 : Fin (2 * 2)))
      densityFixtureY densityFixtureZ = -11/15 := by decide

example : rationalDualValid densityFixtureY = true := by decide
example : rationalDualValid (fun i : Fin (densityInequalityRows 2).length =>
    if i.val = 8 then (1 : ℚ) else 0) = false := by decide
example : checkDensityLPModel densityFixtureCDF 2 (fun i j =>
    if i.val = 9 ∧ j.val = 0 then 1 else densityLP_A 2 i j)
    (densityLP_E 2) (densityLP_b densityFixtureCDF 2) (densityLP_d 2) = false := by decide
example : checkDensityLPModel densityFixtureCDF 2 (densityLP_A 2) (densityLP_E 2)
    (fun i => if i.val = 18 then 0 else densityLP_b densityFixtureCDF 2 i) (densityLP_d 2) = false := by decide

def densityFixtureDual : DensityDualPair 2 := ⟨fun _ => 0, fun _ => 0, fun _ => 0, fun _ => 0⟩

def densityFixtureBands : DensityBands 2 where
  dual := fun _ => densityFixtureDual
  cellLower := fun _ => 1/2
  cellUpper := fun _ => 3/2
  pointLower := fun _ => 1/2
  pointUpper := fun _ => 3/2
  histogram := fun _ => 1
  cornerExcess := 1/15
  histogramError := 1
  fallback := false

theorem density_fixture_checked : checkDensityBands densityFixtureCDF densityFixtureBands = true := by decide

def densityFixtureFallbackCDF : CDFReport 3 := {cdfFixtureReport with radius := 1}
def densityFixtureFallbackBands : DensityBands 2 :=
  {densityFixtureBands with cornerExcess := 0, fallback := true}
def densityFixtureFallbackReport : DensityReport 3 :=
  ⟨densityFixtureFallbackCDF, 2, densityFixtureFallbackBands⟩

theorem density_fixture_fallback_checked :
    checkDensityReport cdfFixtureChain densityFixtureFallbackReport 1 0 0 = true := by decide

example : checkDensityBands densityFixtureFallbackCDF
    {densityFixtureFallbackBands with cellLower := fun _ => 3/4} = false := by decide
example : checkDensityBands densityFixtureFallbackCDF
    {densityFixtureFallbackBands with histogram := fun _ => 2} = false := by decide
example : checkDensityBands densityFixtureFallbackCDF
    {densityFixtureFallbackBands with cornerExcess := 1/10} = false := by decide
example : checkDensityBands densityFixtureFallbackCDF
    {densityFixtureFallbackBands with histogramError := 0} = false := by decide

#print axioms density_fixture_matrix
#print axioms density_fixture_equalities
#print axioms density_fixture_right
#print axioms density_fixture_dimensions
#print axioms density_fixture_residual
#print axioms density_fixture_dual_bound
#print axioms density_fixture_checked
#print axioms density_fixture_fallback_checked

end QuantyraNullCone
