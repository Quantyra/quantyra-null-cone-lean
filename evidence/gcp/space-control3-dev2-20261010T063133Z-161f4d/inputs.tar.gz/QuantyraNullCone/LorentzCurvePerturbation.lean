import QuantyraNullCone.LorentzCurveControl

namespace QuantyraNullCone

open MeasureTheory Set

noncomputable section

def endpointResidual3 (p q p' q' : LorentzPoint3) (k : ℝ) : LorentzPoint3 :=
  (q' - p') - k • (q - p)

def FutureCurve3.adjustCoord {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (p' q' : LorentzPoint3) (k : ℝ) (i : Fin 3) (t : ℝ) : ℝ :=
  p' i + k * (c.coord i t - p i) + c.timeFraction t * endpointResidual3 p q p' q' k i

theorem ac_const3 (a : ℝ) : AbsolutelyContinuousOnInterval (fun _ : ℝ => a) 0 1 := by
  apply ContDiffOn.absolutelyContinuousOnInterval
  fun_prop

theorem FutureCurve3.coord_hasDerivAt {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (i : Fin 3) : ∀ᵐ t ∂curveMeasure, HasDerivAt (c.coord i) (deriv (c.coord i) t) t := by
  have h := ae_restrict_of_ae (c.coordAC i).ae_differentiableAt (s := Icc (0 : ℝ) 1)
  filter_upwards [h, self_mem_ae_restrict measurableSet_Icc] with t ht hmem
  exact (ht (by simpa using hmem)).hasDerivAt

theorem FutureCurve3.timeFraction_AC {p q : LorentzPoint3} (c : FutureCurve3 p q) :
    AbsolutelyContinuousOnInterval c.timeFraction 0 1 := by
  simpa only [FutureCurve3.timeFraction, div_eq_mul_inv, Pi.sub_apply, mul_comm] using
    ((c.coordAC 0).sub (ac_const3 (p 0))).const_mul (q 0 - p 0)⁻¹

theorem FutureCurve3.adjustCoord_AC {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (p' q' : LorentzPoint3) (k : ℝ) (i : Fin 3) :
    AbsolutelyContinuousOnInterval (c.adjustCoord p' q' k i) 0 1 := by
  simpa only [FutureCurve3.adjustCoord, Pi.add_apply, Pi.sub_apply, mul_comm] using
    ((ac_const3 (p' i)).add (((c.coordAC i).sub (ac_const3 (p i))).const_mul k)).add
      (c.timeFraction_AC.const_mul (endpointResidual3 p q p' q' k i))

theorem FutureCurve3.adjustCoord_deriv {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (p' q' : LorentzPoint3) (k : ℝ) (i : Fin 3) :
    ∀ᵐ t ∂curveMeasure, deriv (c.adjustCoord p' q' k i) t =
      k * deriv (c.coord i) t + (deriv (c.coord 0) t / (q 0 - p 0)) *
        endpointResidual3 p q p' q' k i := by
  filter_upwards [c.coord_hasDerivAt i, c.coord_hasDerivAt 0] with t hi h0
  exact (((hi.sub_const (p i)).const_mul k).const_add (p' i) |>.add
    (((h0.sub_const (p 0)).div_const (q 0 - p 0)).mul_const
      (endpointResidual3 p q p' q' k i))).deriv

theorem FutureCurve3.adjust_start {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (p' q' : LorentzPoint3) (k : ℝ) (i : Fin 3) : c.adjustCoord p' q' k i 0 = p' i := by
  simp [FutureCurve3.adjustCoord, FutureCurve3.timeFraction, c.start]

theorem FutureCurve3.adjust_finish {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (hpq : chronological3 p q) (p' q' : LorentzPoint3) (k : ℝ) (i : Fin 3) :
    c.adjustCoord p' q' k i 1 = q' i := by
  have hT : q 0 - p 0 ≠ 0 := ne_of_gt ((spatial_radius_nonneg3 _).trans_lt hpq)
  simp only [FutureCurve3.adjustCoord, FutureCurve3.timeFraction, c.finish, div_self hT,
    one_mul, endpointResidual3, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
  ring

theorem FutureCurve3.adjust_velocity {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (p' q' : LorentzPoint3) (k : ℝ) :
    ∀ᵐ t ∂curveMeasure, acVelocity3 (c.adjustCoord p' q' k) t = k • c.velocity t +
      (deriv (c.coord 0) t / (q 0 - p 0)) • endpointResidual3 p q p' q' k := by
  have h : ∀ᵐ t ∂curveMeasure, ∀ i, deriv (c.adjustCoord p' q' k i) t =
      k * deriv (c.coord i) t + (deriv (c.coord 0) t / (q 0 - p 0)) *
        endpointResidual3 p q p' q' k i := ae_all_iff.mpr (c.adjustCoord_deriv p' q' k)
  filter_upwards [h] with t ht
  ext i
  exact ht i

theorem FutureCurve3.adjust_future {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (hpq : chronological3 p q) (p' q' : LorentzPoint3) {k : ℝ} (hk : 0 ≤ k)
    (he : spatialRadius3 (endpointResidual3 p q p' q' k) ≤ endpointResidual3 p q p' q' k 0) :
    ∀ᵐ t ∂curveMeasure, spatialRadius3 (acVelocity3 (c.adjustCoord p' q' k) t) ≤
      deriv (c.adjustCoord p' q' k 0) t := by
  have hT : 0 ≤ q 0 - p 0 := ((spatial_radius_nonneg3 _).trans_lt hpq).le
  filter_upwards [c.adjust_velocity p' q' k, c.future] with t hv ht
  change spatialRadius3 (acVelocity3 (c.adjustCoord p' q' k) t) ≤
    acVelocity3 (c.adjustCoord p' q' k) t 0
  rw [hv]
  exact future_cone_add3 (future_cone_smul3 ht hk)
    (future_cone_smul3 he (div_nonneg ((spatial_radius_nonneg3 _).trans ht) hT))

/-- Direct endpoint adjustment in the original AC class, with a causal residual. -/
def FutureCurve3.adjust {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (hpq : chronological3 p q) {p' q' : LorentzPoint3}
    (hp' : p' ∈ closedLorentzDiamond3) (hq' : q' ∈ closedLorentzDiamond3)
    {k : ℝ} (hk : 0 ≤ k)
    (he : spatialRadius3 (endpointResidual3 p q p' q' k) ≤ endpointResidual3 p q p' q' k 0) :
    FutureCurve3 p' q' where
  coord := c.adjustCoord p' q' k
  coordAC := c.adjustCoord_AC p' q' k
  start := c.adjust_start p' q' k
  finish := c.adjust_finish hpq p' q' k
  future := c.adjust_future hpq p' q' hk he
  inDiamond t ht := by
    have h0 : acPoint3 (c.adjustCoord p' q' k) 0 = p' := by
      ext i
      exact c.adjust_start p' q' k i
    have h1 : acPoint3 (c.adjustCoord p' q' k) 1 = q' := by
      ext i
      exact c.adjust_finish hpq p' q' k i
    apply causal_diamond_subset_closed3 hp' hq'
    constructor
    · rw [← h0]
      exact ac_causal_increment3 (c.adjustCoord_AC p' q' k)
        (c.adjust_future hpq p' q' hk he) (by constructor <;> norm_num) ht ht.1
    · rw [← h1]
      exact ac_causal_increment3 (c.adjustCoord_AC p' q' k)
        (c.adjust_future hpq p' q' hk he) ht (by constructor <;> norm_num) ht.2

theorem FutureCurve3.adjust_point {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (hpq : chronological3 p q) {p' q' : LorentzPoint3}
    (hp' : p' ∈ closedLorentzDiamond3) (hq' : q' ∈ closedLorentzDiamond3)
    {k : ℝ} (hk : 0 ≤ k)
    (he : spatialRadius3 (endpointResidual3 p q p' q' k) ≤ endpointResidual3 p q p' q' k 0)
    (t : ℝ) : (c.adjust hpq hp' hq' hk he).point t =
      p' + k • (c.point t - p) + c.timeFraction t • endpointResidual3 p q p' q' k := by
  ext i
  rfl

theorem FutureCurve3.adjust_speed_lower {p q : LorentzPoint3} (c : FutureCurve3 p q)
    (hpq : chronological3 p q) {p' q' : LorentzPoint3}
    (hp' : p' ∈ closedLorentzDiamond3) (hq' : q' ∈ closedLorentzDiamond3)
    {k : ℝ} (hk : 0 ≤ k)
    (he : spatialRadius3 (endpointResidual3 p q p' q' k) ≤ endpointResidual3 p q p' q' k 0) :
    ∀ᵐ t ∂curveMeasure, k * c.flatSpeed t ≤ (c.adjust hpq hp' hq' hk he).flatSpeed t := by
  have hT : 0 ≤ q 0 - p 0 := ((spatial_radius_nonneg3 _).trans_lt hpq).le
  filter_upwards [c.adjust_velocity p' q' k, c.future] with t hv ht
  change k * flatProperSpeed3 (c.velocity t) ≤
    flatProperSpeed3 (acVelocity3 (c.adjustCoord p' q' k) t)
  rw [hv]
  have h := flat_proper_speed_add_ge3 (future_cone_smul3 ht hk)
    (future_cone_smul3 he (div_nonneg ((spatial_radius_nonneg3 _).trans ht) hT))
  rw [flat_proper_speed_smul3 k, abs_of_nonneg hk] at h
  exact (le_add_of_nonneg_right (flat_proper_speed_nonneg3 _)).trans h

#print axioms ac_const3
#print axioms FutureCurve3.coord_hasDerivAt
#print axioms FutureCurve3.timeFraction_AC
#print axioms FutureCurve3.adjustCoord_AC
#print axioms FutureCurve3.adjustCoord_deriv
#print axioms FutureCurve3.adjust_start
#print axioms FutureCurve3.adjust_finish
#print axioms FutureCurve3.adjust_velocity
#print axioms FutureCurve3.adjust_future
#print axioms FutureCurve3.adjust_point
#print axioms FutureCurve3.adjust_speed_lower

end
end QuantyraNullCone
