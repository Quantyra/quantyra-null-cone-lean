import QuantyraNullCone.ProbabilityRate
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

namespace QuantyraNullCone

theorem log_ratio_positive {n : ℕ} (hn : 2 ≤ n) :
    0 < Real.log (n : ℝ) / n := by
  have hnR : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
  exact div_pos (Real.log_pos hnR) (by linarith)

end QuantyraNullCone
