import QuantyraNullCone.ImprovedInverse
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Function.L2Space

namespace QuantyraNullCone

open MeasureTheory Set

noncomputable def curveMeasure : Measure ℝ := volume.restrict (Icc (0 : ℝ) 1)

/-- Actual absolutely continuous future curves in the closed null-coordinate diamond. -/
structure FutureCurve (p q : DiamondPoint) where
  u : ℝ → ℝ
  v : ℝ → ℝ
  uAC : AbsolutelyContinuousOnInterval u 0 1
  vAC : AbsolutelyContinuousOnInterval v 0 1
  startU : u 0 = p.1
  startV : v 0 = p.2
  endU : u 1 = q.1
  endV : v 1 = q.2
  inDiamond : ∀ t ∈ Icc (0 : ℝ) 1, (u t, v t) ∈ diamond
  futureU : ∀ᵐ t ∂curveMeasure, 0 ≤ deriv u t
  futureV : ∀ᵐ t ∂curveMeasure, 0 ≤ deriv v t

def FutureCurve.point {p q : DiamondPoint} (c : FutureCurve p q) (t : ℝ) :
    DiamondPoint := (c.u t, c.v t)

noncomputable def FutureCurve.weight {p q : DiamondPoint} (c : FutureCurve p q)
    (t : ℝ) : ℝ := Real.sqrt (deriv c.u t * deriv c.v t)

/-- The Lorentzian length integrand from the paper, with no assumed length estimate. -/
noncomputable def FutureCurve.length {p q : DiamondPoint} (c : FutureCurve p q)
    (rho : DiamondPoint → ℝ) : ℝ :=
  ∫ t, Real.sqrt (2 * rho (c.point t) * deriv c.u t * deriv c.v t) ∂curveMeasure

theorem FutureCurve.integrable_derivU {p q : DiamondPoint} (c : FutureCurve p q) :
    Integrable (deriv c.u) curveMeasure := by
  exact (intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
    c.uAC.intervalIntegrable_deriv

theorem FutureCurve.integrable_derivV {p q : DiamondPoint} (c : FutureCurve p q) :
    Integrable (deriv c.v) curveMeasure := by
  exact (intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
    c.vAC.intervalIntegrable_deriv

theorem FutureCurve.integral_derivU {p q : DiamondPoint} (c : FutureCurve p q) :
    (∫ t, deriv c.u t ∂curveMeasure) = q.1 - p.1 := by
  change (∫ t in Icc (0 : ℝ) 1, deriv c.u t) = _
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le (by norm_num)]
  rw [c.uAC.integral_deriv_eq_sub, c.endU, c.startU]

theorem FutureCurve.integral_derivV {p q : DiamondPoint} (c : FutureCurve p q) :
    (∫ t, deriv c.v t ∂curveMeasure) = q.2 - p.2 := by
  change (∫ t in Icc (0 : ℝ) 1, deriv c.v t) = _
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le (by norm_num)]
  rw [c.vAC.integral_deriv_eq_sub, c.endV, c.startV]

theorem sqrt_coefficient_lipschitz {a b : ℝ} (ha : 1 / 2 ≤ a) (hb : 1 / 2 ≤ b) :
    |Real.sqrt (2 * a) - Real.sqrt (2 * b)| ≤ |a - b| := by
  have ha0 : 0 ≤ 2 * a := by linarith
  have hb0 : 0 ≤ 2 * b := by linarith
  have ha1 : 1 ≤ Real.sqrt (2 * a) := by
    apply (Real.le_sqrt (by norm_num)).mpr
    constructor <;> nlinarith
  have hb1 : 1 ≤ Real.sqrt (2 * b) := by
    apply (Real.le_sqrt (by norm_num)).mpr
    constructor <;> nlinarith
  have hsqA := Real.sq_sqrt ha0
  have hsqB := Real.sq_sqrt hb0
  have hId : (Real.sqrt (2 * a) - Real.sqrt (2 * b)) *
      (Real.sqrt (2 * a) + Real.sqrt (2 * b)) = 2 * (a - b) := by nlinarith
  have hAbs := congrArg abs hId
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ Real.sqrt (2 * a) + Real.sqrt (2 * b)),
    abs_mul, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2)] at hAbs
  have hNonneg := abs_nonneg (Real.sqrt (2 * a) - Real.sqrt (2 * b))
  nlinarith

#print axioms FutureCurve.integral_derivU
#print axioms sqrt_coefficient_lipschitz

end QuantyraNullCone
